const Register = ()=>{
    return (<><h2>Register</h2></>)
}

export default Register;