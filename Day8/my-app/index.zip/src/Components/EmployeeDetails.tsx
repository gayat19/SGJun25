import AddEMployee from "./AddEmployee";
import Employees from "./Employee";

export default function EmployeeDetails(){
    return(<>
    <Employees/>
    <AddEMployee/>
    </>)
}